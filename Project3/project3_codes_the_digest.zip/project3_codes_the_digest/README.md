Group members

Name 				/ Student Number / Name used when committing
Nan Lin 			/ 651025 		 / Lina Lin
Tessa(Hyeri) Song 	/ 597952		 / Tessa Song, Hyeri Song
Nihal Mirpuri 		/ 562439 		 / Nihal Mirpuri


# Deployment Instructions (via terminal)
```
bundle install
rake db:drop db:create db:migrate db:seed
rails s
```