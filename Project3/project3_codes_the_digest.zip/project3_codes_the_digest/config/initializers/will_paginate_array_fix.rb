# Require array module for will_paginate gem

require 'will_paginate/array'
